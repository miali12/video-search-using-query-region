clc;
clear;
close all;

load('allFramesHistograms.mat');
framesdir = './frames/';
siftdir = './sift/';
fnames = dir([siftdir '/*.mat']);
load('kMeans.mat');
[rowskMeans, colskMeans] = size(kMeans);

%region query for 1st image.
fname = [siftdir '/' fnames(878).name];
load(fname, 'imname', 'descriptors', 'positions');
imname = [framesdir '/' imname];
im1 = imread(imname);
figure('name', 'Region Query 1', 'NumberTitle','off');
imshow(im1);
fprintf('Use the mouse to draw a polygon for region query 1, double click to end it.\n');
oninds = selectRegion(im1, positions);
selectedFeats = descriptors(oninds, :);
[rowsSelectedFeats, ColsSelectedFeats] = size(selectedFeats);

histogramForCurrentFrame = zeros(1, colskMeans); 
for i = 1:rowsSelectedFeats
    distToAllWords = dist2(selectedFeats(i,:), kMeans');
    [val, indOfWord] = min(distToAllWords);
    histogramForCurrentFrame(indOfWord) = histogramForCurrentFrame(indOfWord) + 1;
end
clear imname descriptors positions;

similarityScores = zeros(1, length(fnames));
for i = 1:length(fnames)
    a = histogramForCurrentFrame;
    b = matrixOfFramesHistograms(i,:);
    score = (dot(a,b))/((norm(a))*(norm(b))); 
    
    similarityScores(i) = score;    
end
similarityScores(878) = 0;

for i=1:length(fnames)
    fname = [siftdir '/' fnames(i).name];
    load(fname, 'numfeats');
    if numfeats == 0
        similarityScores(i) = 0;
    end
    clear numfeats;
end

figure('name', '5 Most Similar Frames For Query Region 1: top to bottom, left to right, most similar to least simlar', 'NumberTitle','off');
for i=1:5
    [val, index] = max(similarityScores);
    similarityScores(index) = 0;
    fname = [siftdir '/' fnames(index).name];
    load(fname, 'imname');
    imname = [framesdir '/' imname];
    image = imread(imname);
    subplot(3,2,i);
    imshow(image);
end

%region query for 2nd image.
fname = [siftdir '/' fnames(1051).name];
load(fname, 'imname', 'descriptors', 'positions');
imname = [framesdir '/' imname];
im2 = imread(imname);
figure('name', 'Region Query 2', 'NumberTitle','off');
imshow(im2);
fprintf('Use the mouse to draw a polygon for region query 2, double click to end it.\n');
oninds = selectRegion(im2, positions);
selectedFeats = descriptors(oninds, :);
[rowsSelectedFeats, ColsSelectedFeats] = size(selectedFeats);

histogramForCurrentFrame = zeros(1, colskMeans); 
for i = 1:rowsSelectedFeats
    distToAllWords = dist2(selectedFeats(i,:), kMeans');
    [val, indOfWord] = min(distToAllWords);
    histogramForCurrentFrame(indOfWord) = histogramForCurrentFrame(indOfWord) + 1;
end
clear imname descriptors positions;

similarityScores = zeros(1, length(fnames));
for i = 1:length(fnames)
    a = histogramForCurrentFrame;
    b = matrixOfFramesHistograms(i,:);
    score = (dot(a,b))/((norm(a))*(norm(b))); 
    
    similarityScores(i) = score;    
end
similarityScores(1051) = 0;

for i=1:length(fnames)
    fname = [siftdir '/' fnames(i).name];
    load(fname, 'numfeats');
    if numfeats == 0
        similarityScores(i) = 0;
    end
    clear numfeats;
end

figure('name', '5 Most Similar Frames For Query Region 2', 'NumberTitle','off');
for i=1:5
    [val, index] = max(similarityScores);
    similarityScores(index) = 0;
    fname = [siftdir '/' fnames(index).name];
    load(fname, 'imname');
    imname = [framesdir '/' imname];
    image = imread(imname);
    subplot(3,2,i);
    imshow(image);
end

%region query for 3rd image.
fname = [siftdir '/' fnames(1171).name];
load(fname, 'imname', 'descriptors', 'positions');
imname = [framesdir '/' imname];
im3 = imread(imname);
figure('name', 'Region Query 3', 'NumberTitle','off');
imshow(im3);
fprintf('Use the mouse to draw a polygon for region query 3, double click to end it.\n');
oninds = selectRegion(im3, positions);
selectedFeats = descriptors(oninds, :);
[rowsSelectedFeats, ColsSelectedFeats] = size(selectedFeats);

histogramForCurrentFrame = zeros(1, colskMeans); 
for i = 1:rowsSelectedFeats
    distToAllWords = dist2(selectedFeats(i,:), kMeans');
    [val, indOfWord] = min(distToAllWords);
    histogramForCurrentFrame(indOfWord) = histogramForCurrentFrame(indOfWord) + 1;
end
clear imname descriptors positions;

similarityScores = zeros(1, length(fnames));
for i = 1:length(fnames)
    a = histogramForCurrentFrame;
    b = matrixOfFramesHistograms(i,:);
    score = (dot(a,b))/((norm(a))*(norm(b))); 
    
    similarityScores(i) = score;    
end
similarityScores(1171) = 0;

for i=1:length(fnames)
    fname = [siftdir '/' fnames(i).name];
    load(fname, 'numfeats');
    if numfeats == 0
        similarityScores(i) = 0;
    end
    clear numfeats;
end

figure('name', '5 Most Similar Frames For Query Region 3', 'NumberTitle','off');
for i=1:5
    [val, index] = max(similarityScores);
    similarityScores(index) = 0;
    fname = [siftdir '/' fnames(index).name];
    load(fname, 'imname');
    imname = [framesdir '/' imname];
    image = imread(imname);
    subplot(3,2,i);
    imshow(image);
end


%region query for 4th image.
fname = [siftdir '/' fnames(1260).name];
load(fname, 'imname', 'descriptors', 'positions');
imname = [framesdir '/' imname];
im4 = imread(imname);
figure('name', 'Region Query 4', 'NumberTitle','off');
imshow(im4);
fprintf('Use the mouse to draw a polygon for region query 4, double click to end it.\n');
oninds = selectRegion(im4, positions);
selectedFeats = descriptors(oninds, :);
[rowsSelectedFeats, ColsSelectedFeats] = size(selectedFeats);

histogramForCurrentFrame = zeros(1, colskMeans); 
for i = 1:rowsSelectedFeats
    distToAllWords = dist2(selectedFeats(i,:), kMeans');
    [val, indOfWord] = min(distToAllWords);
    histogramForCurrentFrame(indOfWord) = histogramForCurrentFrame(indOfWord) + 1;
end
clear imname descriptors positions;

similarityScores = zeros(1, length(fnames));
for i = 1:length(fnames)
    a = histogramForCurrentFrame;
    b = matrixOfFramesHistograms(i,:);
    score = (dot(a,b))/((norm(a))*(norm(b))); 
    
    similarityScores(i) = score;    
end
similarityScores(1260) = 0;

for i=1:length(fnames)
    fname = [siftdir '/' fnames(i).name];
    load(fname, 'numfeats');
    if numfeats == 0
        similarityScores(i) = 0;
    end
    clear numfeats;
end

figure('name', '5 Most Similar Frames For Query Region 4', 'NumberTitle','off');
for i=1:5
    [val, index] = max(similarityScores);
    similarityScores(index) = 0;
    fname = [siftdir '/' fnames(index).name];
    load(fname, 'imname');
    imname = [framesdir '/' imname];
    image = imread(imname);
    subplot(3,2,i);
    imshow(image);
end