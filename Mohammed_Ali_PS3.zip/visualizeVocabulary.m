clc;
close all;
clear;

framesdir = './frames/';
siftdir = './sift/';

fnames = dir([siftdir '/*.mat']);
N = 50000;  %50,000 descriptor samples.
numOfFramesToSample = 6000;
randomFrames = randi([14 numOfFramesToSample], 1, N);
randomDescriptors = zeros(128, N); %put random descriptors in here.
randomDescIndex = zeros(1, N); %this will contain the indexes of
%the descriptors chosen from each frame; indexes 1 through numfeats. 

%we will draw 50,000 descriptors to cluster using k means.
for i=1:N    
    fname = [siftdir '/' fnames(randomFrames(i)).name];
    load(fname, 'descriptors');
    numfeats = size(descriptors,1);
    if numfeats > 0
        randPickedDesc = randi([1 numfeats], 1, 1);
        randomDescriptors(:,i) = descriptors(randPickedDesc,:);
        randomDescIndex(i) = randPickedDesc;
    else
        randomFrames(i) = 0;
    end
    clear descriptors;
end

%get rid of empty entries for each of the three matrices.
randomDescriptors = randomDescriptors(:,any(randomDescriptors));
validRandomFrames = randomFrames(randomFrames ~= 0); 
randomDescIndex = randomDescIndex(randomDescIndex ~= 0) ;

[membership, kMeans, rms] = kmeansML(1500, randomDescriptors);
save('kMeans.mat', 'kMeans');

%select a random word from means, and find it's most distinct word. %pick a random centroid/visual word.
distOfEachWordToAllOtherWords = dist2(kMeans',kMeans');
maxDist = max(max(distOfEachWordToAllOtherWords));
[i j] = find(distOfEachWordToAllOtherWords == maxDist);
if length(i)>1
    firstWord = i(1);
    secondWord = i(2);
else
    firstWord = i;
    secondWord = j;
end

arrayOfDescIndexesForFirstCentroid = [];
arrayOfDescIndexesForSecondCentroid = [];
%find indexes of descriptors which get mapped to the first and second selected visual words.

for i=1:length(membership)
    if membership(i) == firstWord
        arrayOfDescIndexesForFirstCentroid(end+1) = i;
    elseif membership(i) == secondWord
        arrayOfDescIndexesForSecondCentroid(end+1) = i;
    end
end

%fill up the actual descriptor arrays for the first and second word.
allDescriptorsInFirstCluster = zeros(128, length(arrayOfDescIndexesForFirstCentroid));
allDescriptorsInSecondCluster = zeros(128, length(arrayOfDescIndexesForSecondCentroid));

for i=1:length(arrayOfDescIndexesForFirstCentroid)
     allDescriptorsInFirstCluster(:,i) = randomDescriptors(:,arrayOfDescIndexesForFirstCentroid(i));
end

for i=1:length(arrayOfDescIndexesForSecondCentroid)
     allDescriptorsInSecondCluster(:,i) = randomDescriptors(:,arrayOfDescIndexesForSecondCentroid(i));
end

%calculate distance of each descriptor in the cluster from the centroid.
firstClusterDescriptorDistances = dist2((kMeans(:,firstWord))', allDescriptorsInFirstCluster');
secondClusterDescriptorDistances = dist2((kMeans(:,secondWord))',allDescriptorsInSecondCluster');

%display patches for 1st word.
figure('name', 'Top 25 patches for visual word 1', 'NumberTitle','off');
for i=1:25
    [val, ind] = min(firstClusterDescriptorDistances);
    actualIndOfDesc = arrayOfDescIndexesForFirstCentroid(ind);
    actualFrame = validRandomFrames(actualIndOfDesc);
    actualActualIndOfDesc = randomDescIndex(actualIndOfDesc);
    
    fname = [siftdir '/' fnames(actualFrame).name];
    load(fname, 'imname', 'positions', 'scales', 'orients');
    imname = [framesdir '/' imname]; 
    im = imread(imname); 
    
    patch = getPatchFromSIFTParameters(positions(actualActualIndOfDesc,:),scales(actualActualIndOfDesc), orients(actualActualIndOfDesc), rgb2gray(im));
    subplot(5,5,i);
    imshow(patch);
    firstClusterDescriptorDistances(ind) = [];
    arrayOfDescIndexesForFirstCentroid(ind) = [];
end

%patches for 2nd word.
figure('name', 'Top 25 patches for visual word 2', 'NumberTitle','off');
for i=1:25
    [val, ind] = min(secondClusterDescriptorDistances);
    actualIndOfDesc = arrayOfDescIndexesForSecondCentroid(ind);
    actualFrame = validRandomFrames(actualIndOfDesc);
    actualActualIndOfDesc = randomDescIndex(actualIndOfDesc); 
    
    fname = [siftdir '/' fnames(actualFrame).name];
    load(fname, 'imname', 'positions', 'scales', 'orients');
    imname = [framesdir '/' imname]; 
    im = imread(imname); 
    
    patch = getPatchFromSIFTParameters(positions(actualActualIndOfDesc,:),scales(actualActualIndOfDesc), orients(actualActualIndOfDesc), rgb2gray(im));
    subplot(5,5,i);
    imshow(patch);
    secondClusterDescriptorDistances(ind) = [];
    arrayOfDescIndexesForSecondCentroid(ind) = [];
end


