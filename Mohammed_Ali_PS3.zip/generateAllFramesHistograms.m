clc;
clear;
close all;

load('kMeans.mat');
[rowskMeans, colskMeans] = size(kMeans);
framesdir = './frames/';
siftdir = './sift/';
fnames = dir([siftdir '/*.mat']);
if exist('checkPoint.mat', 'file')
    load('checkPoint.mat');
else
    matrixOfFramesHistograms = zeros(length(fnames), colskMeans);
    currIndex = 1;
end
    
for i = currIndex:length(fnames)
    fname = [siftdir '/' fnames(i).name];
    load(fname, 'descriptors');
    numfeats = size(descriptors,1);
    
    histogramForCurrentFrame = zeros(1, colskMeans); 
    for j = 1:numfeats
       distToAllWords = dist2(descriptors(j,:), kMeans');
       [val, indOfWord] = min(distToAllWords);
       histogramForCurrentFrame(indOfWord) = histogramForCurrentFrame(indOfWord) + 1;
    end
    
    matrixOfFramesHistograms(i,:) = histogramForCurrentFrame;
    clear descriptors;
    currIndex = i+1;
    save('checkPoint.mat', 'matrixOfFramesHistograms', 'currIndex');    
end

save('allFramesHistograms.mat', 'matrixOfFramesHistograms');