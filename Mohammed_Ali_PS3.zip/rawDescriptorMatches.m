clear;
clc;
close all;

load('twoFrameData.mat');
imshow(im1);
fprintf('Use the mouse to draw a polygon, double click to end it.\n');
oninds = selectRegion(im1, positions1); 

euclideanDist = dist2(descriptors1(oninds,:),descriptors2(:,:));
[r, c] = size(oninds);
minDistInd = zeros(r,1);

for i=1:r
    currRow = euclideanDist(i,:);
    minDistVector = sort(currRow);
    minValueInd = find(currRow == minDistVector(1));
    secondMinValueInd = find(currRow == minDistVector(2));
    ratio = minDistVector(1)/minDistVector(2);
    if ratio < 0.8
       minDistInd(i) = minValueInd; 
    end
end

minDistInd = minDistInd(minDistInd~=0);
figure;
fprintf('Here are the matched descriptors in the second image.\n');
imshow(im2);
displaySIFTPatches(positions2(minDistInd,:), scales2(minDistInd), orients2(minDistInd), im2);
