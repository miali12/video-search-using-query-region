clc;
clear;
close all;

load('allFramesHistograms.mat');
framesdir = './frames/';
siftdir = './sift/';
fnames = dir([siftdir '/*.mat']);


%full frame query for image 1.
fname = [siftdir '/' fnames(286).name];
load(fname, 'imname');
imname = [framesdir '/' imname];
im1 = imread(imname);
clear imname;

similarityScores = zeros(1, length(fnames));
for i = 1:length(fnames)
    a = matrixOfFramesHistograms(286, :);
    b = matrixOfFramesHistograms(i,:);
    score = (dot(a,b))/((norm(a))*(norm(b))); 
    
    similarityScores(i) = score;    
end
similarityScores(286) = 0;

for i=1:length(fnames)
    fname = [siftdir '/' fnames(i).name];
    load(fname, 'numfeats');
    if numfeats == 0
        similarityScores(i) = 0;
    end
    clear numfeats;
end

figure('name', 'Full Frame Query 1', 'NumberTitle','off');
imshow(im1);
figure('name', '5 Most Similar Frames For Query 1: top to bottom, left to right, most similar to least simlar', 'NumberTitle','off');
for i=1:5
    [val, index] = max(similarityScores);
    similarityScores(index) = 0;
    fname = [siftdir '/' fnames(index).name];
    load(fname, 'imname');
    imname = [framesdir '/' imname];
    image = imread(imname);
    subplot(3,2,i);
    imshow(image);
end



%full frame query for image 2.
fname = [siftdir '/' fnames(525).name];
load(fname, 'imname');
imname = [framesdir '/' imname];
im2 = imread(imname);
clear imname;

similarityScores = zeros(1, length(fnames));
for i = 1:length(fnames)
    a = matrixOfFramesHistograms(525, :);
    b = matrixOfFramesHistograms(i,:);
    score = (dot(a,b))/((norm(a))*(norm(b))); 
    
    similarityScores(i) = score;    
end
similarityScores(525) = 0;

for i=1:length(fnames)
    fname = [siftdir '/' fnames(i).name];
    load(fname, 'numfeats');
    if numfeats == 0
        similarityScores(i) = 0;
    end
    clear numfeats;
end

figure('name', 'Full Frame Query 2', 'NumberTitle','off');
imshow(im2);
figure('name', '5 Most Similar Frames For Query 2', 'NumberTitle','off');
for i=1:5
    [val, index] = max(similarityScores);
    similarityScores(index) = 0;
    fname = [siftdir '/' fnames(index).name];
    load(fname, 'imname');
    imname = [framesdir '/' imname];
    image = imread(imname);
    subplot(3,2,i);
    imshow(image);
end


%full frame query for image 3.
fname = [siftdir '/' fnames(772).name];
load(fname, 'imname');
imname = [framesdir '/' imname];
im3 = imread(imname);
clear imname;

similarityScores = zeros(1, length(fnames));
for i = 1:length(fnames)
    a = matrixOfFramesHistograms(772, :);
    b = matrixOfFramesHistograms(i,:);
    score = (dot(a,b))/((norm(a))*(norm(b))); 
    
    similarityScores(i) = score;    
end
similarityScores(772) = 0;

for i=1:length(fnames)
    fname = [siftdir '/' fnames(i).name];
    load(fname, 'numfeats');
    if numfeats == 0
        similarityScores(i) = 0;
    end
    clear numfeats;
end

figure('name', 'Full Frame Query 3', 'NumberTitle','off');
imshow(im3);
figure('name', '5 Most Similar Frames For Query 3', 'NumberTitle','off');
for i=1:5
    [val, index] = max(similarityScores);
    similarityScores(index) = 0;
    fname = [siftdir '/' fnames(index).name];
    load(fname, 'imname');
    imname = [framesdir '/' imname];
    image = imread(imname);
    subplot(3,2,i);
    imshow(image);
end
